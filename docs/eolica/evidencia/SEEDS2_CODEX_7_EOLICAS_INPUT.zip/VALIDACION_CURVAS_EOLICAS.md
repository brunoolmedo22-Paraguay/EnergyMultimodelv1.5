# SEEDS2 - Validación de curvas eólicas

Fecha de consulta y cierre: 9 de noviembre de2026 (America/Asuncion). Investigación aislada; no se modificó el repositorio.

## Dictamen

3 equipos LISTOS PARA INCORPORACIÓN, 5 candidatos adicionales priorizados pero PENDIENTES, y 7 fichas profundas de alternativas. Los ocho priorizados NO son ocho equipos aprobados. No se emitió autorización de integración.

Los listos son Vergnet GEV MP C275, Vestas V47-660 de un generador y Vestas V52-850 OptiSpeed a104.2dB(A). Esta selección final no satisface la diversidad deseada en microeólica. Los motivos de exclusión se conservan individualmente.

## Criterios y reproducibilidad

- Se calcula epsilon_P=100*abs(Pmax-Pnom)/Pnom. Tablas oficiales:1%; gráficos:objetivo3%. Se aplica1% también como filtro inicial a tablas de ensayos, explicitando que no reemplaza incertidumbre experimental.
- Velocidades estrictamente crecientes, potencia finita y no negativa, áreaHAWT=piD²/4, rho conocida y cut-out documentado. No se impone monotonía.
- No se extrapola una curva truncada. El valor al cut-out en una tabla pertenece a la rama operativa: el disparo se aplica por separado en v>=cut-out.
- V nominal inferida se separa de publicada. Se registran primer punto>=99% y primer punto exactamente nominal. El99% es un criterio de lectura de esta misión, no una medición adicional.
- La corrección por densidad de producción es velocidad equivalente. Su uso fuera de las condiciones nominales es una aproximación de SEEDS2, no una nueva curva certificada.
- Potencia eléctrica de fabricante: no reaplicar rendimientos de rotor, multiplicadora o generador. Los consumos negativos son reales: las tablas RAW los preservan.
- Se revisaron68 identidades/candidatos (uno con potencia nominal no confirmada), no cientos.32 CSV del archivoNLR recibieron cribado numérico.15 equipos tienen ficha profunda,8 fueron priorizados y3 superaron todos los requisitos.

## Resumen cuantitativo

| Modelo | Estado | Pnom kW | Pmax kW | epsilon % | N | Dominio m/s |
|---|---|---:|---:|---:|---:|---|
|Aria Libellula 20kW|PENDIENTE|20|19.9|0.50000|21|0..20|
|Northern Power Systems 100C-21|PENDIENTE|100|100|0.00000|23|3..25|
|Northern Power Systems 100C-24|PENDIENTE|95|95.3|0.31579|23|3..25|
|Vergnet GEV MP C 275 kW|LISTO PARA INCORPORACIÓN|275|275|0.00000|21|2.5..25|
|EWT DW54-500|PENDIENTE|500|499.998|0.00036|23|2.9913..24.8634|
|EWT DW54-900|PENDIENTE|900|899.999|0.00006|23|2.9913..24.8634|
|Vestas V47-660 kW|LISTO PARA INCORPORACIÓN|660|660|0.00000|16|4..25|
|Vestas V52-850 kW OptiSpeed|LISTO PARA INCORPORACIÓN|850|850|0.00000|16|4..25|
|superwind SW 1250|PENDIENTE|1.25|1.25002|0.00129|23|2.9999..15.9999|
|SD Wind Energy SD6 (240 VAC, 1 fase, 60 Hz)|PENDIENTE|6|6.119|1.98333|32|0.56..15.99|
|Tozzi Nord TN535|PENDIENTE|9.9|10.15|2.52525|30|0.54..14.94|
|Wind Energy Solutions / Ecoways WES250|PENDIENTE|250|250|0.00000|18|0..16|
|Aria Libellula 50kW / variante49kW|PENDIENTE|49|50.4|2.85714|26|0..25|
|Aria Libellula 60i rotor19m|PENDIENTE|55|59.9|8.90909|21|0..20|
|Northern Power Systems 100C-28|PENDIENTE|90|90|0.00000|16|3..18|

## Digitalización EWT

Se usó PyMuPDF1.26.6 para recuperar el centro de los polígonos azules del PDF original. Los ejes son lineales.24 marcas x(2..25m/s) se ajustaron por mínimos cuadrados; el eje y usa grillas0..1000kW. Se conservaron23 vértices por curva, con mayor densidad de nodos en el ascenso que en los rangos constantes por metro de velocidad. No se crearon nodos físicos de arranque desconocidos.

Se reconstruyó cada gráfico y se superpuso en el documento. Una segunda lectura raster a600dpi detectó el trazo azul en11 cortes verticales. Esta comprobación es independiente de la extracción vectorial, pero usa el mismo documento: mide fidelidad de lectura, NO incertidumbre del fabricante.

| Equipo | Máximo error kW | RMSE kW | Máximo/Pnom % | Resolución raster kW/píxel | m/s/píxel |
|---|---:|---:|---:|---:|---:|
|DW54-500|2.896974|1.447021|0.5794|0.728566|0.020586|
|DW54-900|6.115184|2.298521|0.6795|0.728566|0.020586|

El grosor del trazo (~1.2pt) equivale aproximadamente a7.5kW; la resolución de raster no es la precisión total. Hay un desajuste de posición entre nodos y ticks, hasta~0.14m/s al extremo. Se conserva sin forzar el último vértice a25. El hueco residual bloquea la clasificación LISTO, aunque la reconstrucción sea fiel.

## Resultado por equipo

### Aria Libellula 20kW

La tabla termina en 20 m/s y el cut-out es 25 m/s. Falta la rama decreciente 20..25; mantener 16.4 kW sería una extrapolación no autorizada.

Nominal=20kW; pico=19.9kW; epsilon=0.500000%; primer>=99%=11.0; primer exacto=None; V nominal registrada=10.

| Verificación | Resultado |
|---|---|
|finitos|CUMPLE|
|velocidad_estricta|CUMPLE|
|potencia_no_negativa|CUMPLE|
|nominal_dentro_tolerancia|CUMPLE|
|densidad_conocida|CUMPLE|
|cut_out_numerico_documentado|CUMPLE|
|cubre_hasta_cut_out|NO CUMPLE|
|control_transcripcion|CUMPLE|
|cp_electrico_menor_betz|CUMPLE|
|area_publicada_coherente|NO APLICA / no evaluado|

Fuente: https://www.aria-srl.it/aria-staging/wp-content/uploads/2016/09/Power-Curve-AEP-Libellula-20kW.pdf; página PDF 1; SHA256 d70a5735a71efa1d58bf572528f692582bfb50f1072130d5037e0a494bcc23be

- No elegir automáticamente altura: el perfil debe representar viento a buje.
- V nominal publicada 10 m/s: tabla 19.3 kW. Primer punto >=99% de 20 kW a 11 m/s; se conservan ambas magnitudes.
- Condiciones: 15 °C, 1013 mbar, 1.225 kg/m³, flujo horizontal sin perturbaciones, equipo en perfecto estado. Conexión directa a red, sin inversor.

### Northern Power Systems 100C-21

La tabla neta original incluye -0.6 kW a 1 y 2 m/s. La propuesta conserva sólo la rama no negativa: requiere aceptar explícitamente que los consumos auxiliares quedan fuera del perfil de generación.

Nominal=100kW; pico=100kW; epsilon=0.000000%; primer>=99%=15.0; primer exacto=15.0; V nominal registrada=15.

| Verificación | Resultado |
|---|---|
|finitos|CUMPLE|
|velocidad_estricta|CUMPLE|
|potencia_no_negativa|CUMPLE|
|nominal_dentro_tolerancia|CUMPLE|
|densidad_conocida|CUMPLE|
|cut_out_numerico_documentado|CUMPLE|
|cubre_hasta_cut_out|CUMPLE|
|control_transcripcion|CUMPLE|
|cotejo_nlr_tabla|CUMPLE|
|cp_electrico_menor_betz|CUMPLE|
|area_publicada_coherente|NO APLICA / no evaluado|

Fuente: https://northernpower.com/wp/wp-content/uploads/2025/11/brochure-NPS-100C-21_ed2020_light_ENG.pdf; página PDF 2; SHA256 b1977a516fda839d4d68410d92ff8587ce21908c6203d1b1185a505aa14f2288

Contraste secundario independiente de transcripción: {'source': 'NLR/NREL, archivo CSV con commit fijado en manifest.json', 'matched_points': 23, 'max_error_kw': 0.0}

- Rama de generación propuesta: v=3..25 m/s. El CSV *_raw preserva todos los valores, incluidos negativos.
- La leyenda del gráfico dice NPS 100C-24 dentro del folleto 100C-21: contradicción editorial. Identidad fijada por portada, título de curva, tabla de especificaciones y rotor 20.7 m; tabla contrastada con NLR independiente.
- Condiciones estándar 1.225 kg/m³, equivalentes a 15 °C al nivel del mar. Punto de medición exacto no indicado.

### Northern Power Systems 100C-24

Requiere política explícita para auxiliares negativos y punto de 3 m/s positivo bajo el cut-in de 3.5 m/s. El clip actual recortaría 95.3 a 95 kW.

Nominal=95kW; pico=95.3kW; epsilon=0.315789%; primer>=99%=12.0; primer exacto=None; V nominal registrada=12.

| Verificación | Resultado |
|---|---|
|finitos|CUMPLE|
|velocidad_estricta|CUMPLE|
|potencia_no_negativa|CUMPLE|
|nominal_dentro_tolerancia|CUMPLE|
|densidad_conocida|CUMPLE|
|cut_out_numerico_documentado|CUMPLE|
|cubre_hasta_cut_out|CUMPLE|
|control_transcripcion|CUMPLE|
|cotejo_nlr_tabla|CUMPLE|
|cp_electrico_menor_betz|CUMPLE|
|area_publicada_coherente|NO APLICA / no evaluado|

Fuente: https://northernpower.com/wp/wp-content/uploads/2024/04/brochure-NPS-100C-24_ed2020_light_ENG.pdf; página PDF 2; SHA256 ef3d0e58462d4ea80fe5a8c7060cb1417f9e674b5bad4da15d1323a2d0f5ac92

Contraste secundario independiente de transcripción: {'source': 'NLR/NREL, archivo CSV con commit fijado en manifest.json', 'matched_points': 23, 'max_error_kw': 0.0}

- Potencia nominal eléctrica real: 95 kW. No usar 100 kW por el nombre comercial.
- Tabla completa original con -0.6 kW a 1 y 2 m/s guardada como nps24_raw. Rama de generación propuesta sin recortar máximos.
- La tabla publica 1.2 kW a 3 m/s, la portada menciona generación desde 3 m/s y especificación cut-in 3.5 m/s. Resolución de 1 m/s y control de arranque pueden explicar parte de la diferencia; no se demuestra equivalencia exacta.
- P(12)=94.7 kW (~99.68%); primer punto >=99% a 12 m/s, coherente con nominal declarada.

### Vergnet GEV MP C 275 kW

Tabla oficial eléctrica a 1.225 kg/m³, dominio hasta 25 m/s y meseta 12..25 explícita. V nominal se deriva a 12 m/s; no se atribuye al fabricante como especificación publicada.

Nominal=275kW; pico=275kW; epsilon=0.000000%; primer>=99%=12.0; primer exacto=12.0; V nominal registrada=12.0.

| Verificación | Resultado |
|---|---|
|finitos|CUMPLE|
|velocidad_estricta|CUMPLE|
|potencia_no_negativa|CUMPLE|
|nominal_dentro_tolerancia|CUMPLE|
|densidad_conocida|CUMPLE|
|cut_out_numerico_documentado|CUMPLE|
|cubre_hasta_cut_out|CUMPLE|
|control_transcripcion|CUMPLE|
|cp_electrico_menor_betz|CUMPLE|
|area_publicada_coherente|CUMPLE|

Fuente: https://www.vergnet.com/wp-content/uploads/2023/06/DC-11-00-01-EN_GEV_MP-C_275_kW.pdf; página PDF 7; SHA256 05e8d865be60bbb96e9968c96edc6ca221fc5879c25c3c4eab4439d89ea79efa

- No se asigna una clase individual entre II y IV: debe elegirse la configuración de sitio.
- Tabla: 275 kW a 12 m/s y hasta 25 m/s. El punto 25,275 representa la rama operativa, antes del disparo; SEEDS2 pone cero para v>=25.
- Frontera: tabla de potencia eléctrica del aerogenerador, medición exacta no explicitada. No deducir de la mención de transformador en gabinete que sus pérdidas están incluidas.

### EWT DW54-500

Digitalización validada. El extremo numérico queda ~0.14 m/s antes de 25 por el propio dibujo. Falta aceptar dominio restringido o documentar ese intervalo; no se prolonga la curva.

Nominal=500kW; pico=499.99819kW; epsilon=0.000361%; primer>=99%=9.950661278720233; primer exacto=None; V nominal registrada=9.950661278720233.

| Verificación | Resultado |
|---|---|
|finitos|CUMPLE|
|velocidad_estricta|CUMPLE|
|potencia_no_negativa|CUMPLE|
|nominal_dentro_tolerancia|CUMPLE|
|densidad_conocida|CUMPLE|
|cut_out_numerico_documentado|CUMPLE|
|cubre_hasta_cut_out|NO CUMPLE|
|control_transcripcion|NO APLICA / no evaluado|
|cp_electrico_menor_betz|CUMPLE|
|area_publicada_coherente|NO APLICA / no evaluado|
|control_raster_menor_3pct|CUMPLE|

Fuente: https://ewtdirectwind.com/wp-content/uploads/2023/11/EWT_DW54.pdf; página PDF 2; SHA256 479f75dbf95e982b4ce27c0ae3d5e90769fbfd88721ddaf2ba3f90f177acf1c1

- Densidad 1.225 kg/m³, 15 °C, exponente de cizalladura 1/7, terreno no complejo, flujo sin inclinación y palas limpias.
- Fuente: curva azul de potencia kW; curva roja Cp no se usa como potencia. Ejes lineales. 23 vértices recuperados sin redondear velocidades a enteros.
- Potencia eléctrica: sin pérdidas de transformador ni otras externas según folleto. Punto exacto no explicitado.
- SEEDS2 recibe viento a altura de buje. No reproduce perfil vertical 1/7 sobre el rotor ni ajusta automáticamente altura de medición.
- La antigua página /products/dw54/ aparece en buscadores, pero devolvió404 en verificación directa. Se usa /turbines/ como página oficial activa y se conserva el PDF técnico200 como evidencia de parámetros.
- V nominal no publicada. Primer vértice >=99% nominal: 9.95066 m/s.

### EWT DW54-900

Digitalización validada. El extremo numérico queda ~0.14 m/s antes de 25 por el propio dibujo. Falta aceptar dominio restringido o documentar ese intervalo; no se prolonga la curva.

Nominal=900kW; pico=899.9995kW; epsilon=0.000056%; primer>=99%=13.92734453877764; primer exacto=None; V nominal registrada=13.92734453877764.

| Verificación | Resultado |
|---|---|
|finitos|CUMPLE|
|velocidad_estricta|CUMPLE|
|potencia_no_negativa|CUMPLE|
|nominal_dentro_tolerancia|CUMPLE|
|densidad_conocida|CUMPLE|
|cut_out_numerico_documentado|CUMPLE|
|cubre_hasta_cut_out|NO CUMPLE|
|control_transcripcion|NO APLICA / no evaluado|
|cp_electrico_menor_betz|CUMPLE|
|area_publicada_coherente|NO APLICA / no evaluado|
|control_raster_menor_3pct|CUMPLE|

Fuente: https://ewtdirectwind.com/wp-content/uploads/2023/11/EWT_DW54.pdf; página PDF 1; SHA256 479f75dbf95e982b4ce27c0ae3d5e90769fbfd88721ddaf2ba3f90f177acf1c1

- Densidad 1.225 kg/m³, 15 °C, exponente de cizalladura 1/7, terreno no complejo, flujo sin inclinación y palas limpias.
- Fuente: curva azul de potencia kW; curva roja Cp no se usa como potencia. Ejes lineales. 23 vértices recuperados sin redondear velocidades a enteros.
- Potencia eléctrica: sin pérdidas de transformador ni otras externas según folleto. Punto exacto no explicitado.
- SEEDS2 recibe viento a altura de buje. No reproduce perfil vertical 1/7 sobre el rotor ni ajusta automáticamente altura de medición.
- La antigua página /products/dw54/ aparece en buscadores, pero devolvió404 en verificación directa. Se usa /turbines/ como página oficial activa y se conserva el PDF técnico200 como evidencia de parámetros.
- V nominal no publicada. Primer vértice >=99% nominal: 13.92734 m/s.

### Vestas V47-660 kW

Tabla oficial de la versión de un generador, rho=1.225; rango 19..25 publicado explícitamente. No mezclar con V47-660/200.

Nominal=660kW; pico=660kW; epsilon=0.000000%; primer>=99%=15.0; primer exacto=17.0; V nominal registrada=15.

| Verificación | Resultado |
|---|---|
|finitos|CUMPLE|
|velocidad_estricta|CUMPLE|
|potencia_no_negativa|CUMPLE|
|nominal_dentro_tolerancia|CUMPLE|
|densidad_conocida|CUMPLE|
|cut_out_numerico_documentado|CUMPLE|
|cubre_hasta_cut_out|CUMPLE|
|control_transcripcion|CUMPLE|
|cp_electrico_menor_betz|CUMPLE|
|area_publicada_coherente|CUMPLE|

Fuente: https://sti2d.ecolelamache.org/ressources/EE/premiere/TP/serie%202/Vestas_V47.pdf; página PDF 12; SHA256 0aaf05e8c558f936f671759744ca56ae6ca2f9c6e8f9186783ca18ab76f1cad1

- Curva tabulada calculada por el fabricante a partir de perfiles NACA63.600/FFA-W3 y TI=10%, viento medio 10 min a buje y normal al rotor. No es un ajuste teórico creado para esta misión.
- No confundir tabla calculada p.PDF12 con medición TWE de apéndice ni con variante de dos generadores p.PDF14.
- V nominal publicada 15 m/s (folleto p.PDF4): P(15)=657 kW (99.55%). Primera velocidad >=99% a 15; primer valor exactamente 660 a 17.
- Rearranque 20 m/s en p.PDF10 (impresa4). SEEDS2 registra el dato pero no simula histéresis; idóneo para balance energético estático, no para validar secuencias de parada/rearranque.

### Vestas V52-850 kW OptiSpeed

Tabla oficial a 1.225 kg/m³ y modo acústico 104.2 dB(A). Rango 18..25 expresamente constante. V nominal inferida, sin mezclar otras curvas acústicas.

Nominal=850kW; pico=850kW; epsilon=0.000000%; primer>=99%=15.0; primer exacto=17.0; V nominal registrada=17.0.

| Verificación | Resultado |
|---|---|
|finitos|CUMPLE|
|velocidad_estricta|CUMPLE|
|potencia_no_negativa|CUMPLE|
|nominal_dentro_tolerancia|CUMPLE|
|densidad_conocida|CUMPLE|
|cut_out_numerico_documentado|CUMPLE|
|cubre_hasta_cut_out|CUMPLE|
|control_transcripcion|CUMPLE|
|cp_electrico_menor_betz|CUMPLE|
|area_publicada_coherente|CUMPLE|

Fuente: https://mkwind.pl/uploads/filemanager/PDF/V52-850kWh%20Gen%20Spec-1-1.pdf; página PDF 8; SHA256 39e52a04fd0733c0deef916e18f91d1c5edca1ea10a37e681a14a59b19f34263

- Curvas/tablas calculadas oficialmente con perfiles NACA63/FFA-W3. No son mediciones nuevas ni una curva genérica cúbica.
- Curva nominal seleccionada: ruido 104.2 dB(A), TI=10%, viento medio 10 minutos a buje perpendicular al plano del rotor. No usar tablas 103/102/101/100 dB(A).
- Frontera publicada p.PDF7: excluye pérdidas del transformador y cables de alta tensión. No reaplicar eficiencias de rotor/caja/generador.
- V nominal no fijada en la tabla seleccionada: primer >=99% a 15 m/s; primer valor exactamente 850 a 17 m/s. Se propone 17 derivada (criterio alcance exacto).
- Rearranque 20 m/s p.PDF6. El modelo actual no representa histéresis ni ventanas de control de 10 minutos.

### superwind SW 1250

Curva eléctrica oficial legible, pero no declara densidad. Operación publicada hasta 35 m/s sin cut-out automático numérico; gráfico sólo hasta ~16. Se necesita política aceptada y frontera DC/AC explícita.

Nominal=1.25kW; pico=1.2500161kW; epsilon=0.001287%; primer>=99%=11.498917396354946; primer exacto=None; V nominal registrada=11.5.

| Verificación | Resultado |
|---|---|
|finitos|CUMPLE|
|velocidad_estricta|CUMPLE|
|potencia_no_negativa|CUMPLE|
|nominal_dentro_tolerancia|CUMPLE|
|densidad_conocida|NO CUMPLE|
|cut_out_numerico_documentado|NO CUMPLE|
|cubre_hasta_cut_out|NO CUMPLE|
|control_transcripcion|NO APLICA / no evaluado|
|area_publicada_coherente|NO APLICA / no evaluado|

Fuente: https://www.superwind.com/fileadmin/user_upload/Downloads/1250/Power_curve_SW_1250.pdf; página PDF 1; SHA256 a23c99500d28833feb53aa5b0e58e2d79f53cf646009e395c17a1a540d1ee79d

- Manual: nominal 1250 W, 24/48 VDC, rango 3.5..35 m/s en producción y supervivencia 50 m/s frenado. 35 m/s es límite de operación, no un punto de curva ni cut-out automático probado.
- No trasladar rho=1.225 de un ensayo académico AC sobre tejados a esta curva oficial DC de 2025 sin demostrar equivalencia.
- Extracción vectorial guardada como exploratoria. No cuenta como curva aprobada: no se hizo control raster cuantitativo de esta candidata pendiente.

### SD Wind Energy SD6 (240 VAC, 1 fase, 60 Hz)

Tabla certificada con negativos y pico 6.119 kW (1.98% sobre 6; 17.67% sobre rating AWEA5.2). Supera regla actual 1%; no hay datos a partir de 15.99 m/s ni política aceptada de funcionamiento continuo.

Nominal=6kW; pico=6.119kW; epsilon=1.983333%; primer>=99%=12.98; primer exacto=13.5; V nominal registrada=None.

| Verificación | Resultado |
|---|---|
|finitos|CUMPLE|
|velocidad_estricta|CUMPLE|
|potencia_no_negativa|NO CUMPLE|
|nominal_dentro_tolerancia|NO CUMPLE|
|densidad_conocida|CUMPLE|
|cut_out_numerico_documentado|NO CUMPLE|
|cubre_hasta_cut_out|NO CUMPLE|
|control_transcripcion|NO APLICA / no evaluado|
|cp_electrico_menor_betz|CUMPLE|
|area_publicada_coherente|CUMPLE|

Fuente: https://smallwindcertification.org/wp-content/uploads/2021/04/SWCC-11-04-Summary-Report-2020.pdf; página PDF 3; SHA256 4eb008f8b98d92ef908f34fef30f328d3c8d0d55a8f728ed13b160f9d61fdeb0

- No confundir nominal comercial 6 kW con potencia AWEA a 11 m/s 5.2 kW ni con pico certificado 6.1 kW.
- Encabezado de tabla dice kW pero valores como 6119 corresponden a W. Conversión /1000 verificada con figura en W y rating del informe.
- Informe contiene aparentes residuos editoriales: DS3000 p.1 y área17m² en pies de gráficos; descripción p.1 indica23.7m². Se conserva23.7 con conflicto explícito, no se adopta17.
- Diámetro5.5 m proviene de NLR para el modelo ensayado; guía comercial posterior SD6 dice5.6m. No trasladar automáticamente esa geometría al ensayo antiguo.

### Tozzi Nord TN535

Incompatibilidad entre especificación 2017 de 9.9kW/6.7m/s y ensayo 2015 con máximo10.15kW/registro de referencia10.3. Falta demostrar misma revisión de control y resolver tolerancia nominal.

Nominal=9.9kW; pico=10.15kW; epsilon=2.525253%; primer>=99%=7.5; primer exacto=None; V nominal registrada=6.7.

| Verificación | Resultado |
|---|---|
|finitos|CUMPLE|
|velocidad_estricta|CUMPLE|
|potencia_no_negativa|NO CUMPLE|
|nominal_dentro_tolerancia|NO CUMPLE|
|densidad_conocida|CUMPLE|
|cut_out_numerico_documentado|CUMPLE|
|cubre_hasta_cut_out|NO CUMPLE|
|control_transcripcion|NO APLICA / no evaluado|
|cp_electrico_menor_betz|CUMPLE|
|area_publicada_coherente|CUMPLE|

Fuente: https://upcommons.upc.edu/server/api/core/bitstreams/b6d446f6-e584-4dc0-b2e4-84353fd8b9c0/content; página PDF 4; SHA256 867a37037d6a2a7644dd44901d75d48c475d5ba04666be2ea557c2c52ccaf5e5

- Documento fabricante públicamente alojado en MWPS; estado comercial no verificado.
- Tabla medida digital en imagen: 30 bins, máximo10.15kW; la sección BWEA dice10.3kW. Se registran ambos sin forzar concordancia.
- Las versiones históricas10kW/7.5m/s citadas en otras fuentes no justifican reemplazar nominal9.9 de la revisión2017.

### Wind Energy Solutions / Ecoways WES250

Tabla oficial, pero falta densidad. Ficha actual cut-in>3 y corte22; anterior cut-in<3 y corte25. No mezclar revisiones ni interpretar etiqueta kWh de tabla de potencia como energía.

Nominal=250kW; pico=250kW; epsilon=0.000000%; primer>=99%=12.5; primer exacto=12.5; V nominal registrada=13.

| Verificación | Resultado |
|---|---|
|finitos|CUMPLE|
|velocidad_estricta|CUMPLE|
|potencia_no_negativa|CUMPLE|
|nominal_dentro_tolerancia|CUMPLE|
|densidad_conocida|NO CUMPLE|
|cut_out_numerico_documentado|CUMPLE|
|cubre_hasta_cut_out|NO CUMPLE|
|control_transcripcion|NO APLICA / no evaluado|
|area_publicada_coherente|NO APLICA / no evaluado|

Fuente: https://ecoways.com/hubfs/WES%20Spec%20Sheets/WES250-NL%20Spec%20Sheet..pdf; página PDF 2; SHA256 f7d862ac79b2c2502954a63e9c4c09d163a03bcf80fddf054a023a97148dbda7

- Curva máxima250 a12.5m/s; nominal publicada13. Tabla actual rotula unidad kWh en columna de potencia, pero gráfico y ficha identifican kW. Se conserva como kW con advertencia.
- Original Brochure_WES_250.pdf de WES (copia SDL) publica25 m/s; Ecoways actual publica22. Sin revisión visible de ninguna, no declarar equivalencia de operación.
- Las cifras de AEP no demuestran por sí solas la densidad de referencia de la curva.

### Aria Libellula 50kW / variante49kW

La ficha declara49kW nominales, la curva alcanza50.4 (2.86%). Supera objetivo1% de tabla y clip de producción; además curva positiva a3m/s con cut-in3.5.

Nominal=49kW; pico=50.4kW; epsilon=2.857143%; primer>=99%=13.0; primer exacto=None; V nominal registrada=13.

| Verificación | Resultado |
|---|---|
|finitos|CUMPLE|
|velocidad_estricta|CUMPLE|
|potencia_no_negativa|CUMPLE|
|nominal_dentro_tolerancia|NO CUMPLE|
|densidad_conocida|CUMPLE|
|cut_out_numerico_documentado|CUMPLE|
|cubre_hasta_cut_out|CUMPLE|
|control_transcripcion|NO APLICA / no evaluado|
|cp_electrico_menor_betz|CUMPLE|
|area_publicada_coherente|NO APLICA / no evaluado|

Fuente: https://www.aria-srl.it/aria-staging/wp-content/uploads/2020/02/Power-Curve-AEP-Libellula-50kW-19.4m.pdf; página PDF 1; SHA256 d559a17c08cb4e6a832830902eac7c3f77bafca2802bc0de79bd726127dc2670

- No cambiar nominal a50 por el nombre comercial para hacer pasar la prueba:49 es especificación publicada.
- La curva llega a25 m/s sin meseta artificial, pero el control de49 frente a50/55 necesita aclaración.

### Aria Libellula 60i rotor19m

Generador nominal55kW, máximo declarado en red59.9. Modelo científico necesita separar nominal de generador y capacidad eléctrica de salida. Curva termina20 y corte25.

Nominal=55kW; pico=59.9kW; epsilon=8.909091%; primer>=99%=10.0; primer exacto=None; V nominal registrada=11.

| Verificación | Resultado |
|---|---|
|finitos|CUMPLE|
|velocidad_estricta|CUMPLE|
|potencia_no_negativa|CUMPLE|
|nominal_dentro_tolerancia|NO CUMPLE|
|densidad_conocida|CUMPLE|
|cut_out_numerico_documentado|CUMPLE|
|cubre_hasta_cut_out|NO CUMPLE|
|control_transcripcion|NO APLICA / no evaluado|
|cp_electrico_menor_betz|CUMPLE|
|area_publicada_coherente|NO APLICA / no evaluado|

Fuente: https://www.aria-srl.it/aria-staging/wp-content/uploads/2015/07/Power-CT-curve-AEP-Libellula-60i-18-19m.pdf; página PDF 1; SHA256 2aa119ef586973894964e696a350b6f6d9dbbcb2f8ea1dcf9fa53f0539aa78d7

- No usar 60kW de nombre comercial como nominal certificada; la ficha separa55kW del generador y59.9kW máximo a red. La comparación contra55 da8.91%.

### Northern Power Systems 100C-28

Tabla completa y corte18 claros. Consumo auxiliar negativo y falta de datos2.5..3 requieren política explícita. Control visual corrigió capa textual887.3 a87.3 kW.

Nominal=90kW; pico=90kW; epsilon=0.000000%; primer>=99%=11.0; primer exacto=12.0; V nominal registrada=12.

| Verificación | Resultado |
|---|---|
|finitos|CUMPLE|
|velocidad_estricta|CUMPLE|
|potencia_no_negativa|CUMPLE|
|nominal_dentro_tolerancia|CUMPLE|
|densidad_conocida|CUMPLE|
|cut_out_numerico_documentado|CUMPLE|
|cubre_hasta_cut_out|CUMPLE|
|control_transcripcion|NO APLICA / no evaluado|
|cp_electrico_menor_betz|CUMPLE|
|area_publicada_coherente|NO APLICA / no evaluado|

Fuente: https://northernpower.com/wp/wp-content/uploads/2025/11/brochure-NPS-100C-28_ed2019_light_ENG.pdf; página PDF 2; SHA256 f0efa1c958df88a2ff0a3f87c51ea3a1f5bbea903b627115dfe10c1146ad6d47

- A10m/s la tabla VISIBLE dice87.3; pdftotext devuelve887.3 por un glifo/texto superpuesto. No se califica como error de física del fabricante. Evidencia:qa/nps28.png.
- No mezclar con variantes27.4m o27.6m: ésta tiene rotor28m, tabla hasta18m/s y claseS.

## Limitaciones de la investigación

No se obtuvo un conjunto de8-10 incorporaciones sin condiciones. Hay curvas científicamente útiles que el contrato actual no representa fielmente: consumos auxiliares, potencia pico distinta de nominal y control en vientos altos. No se degradan esas curvas para hacerlas pasar.

Las condiciones de operación certificadas no se transfieren entre versiones por nombre comercial. Curvas calculadas OEM tabuladas se clasificanA por su procedencia y explicitación, no como ensayos. Si se exige exclusivamente evidencia medida, los Vestas calculados deben reevaluarse; las tablas calculadas no son curvas genéricas creadas por el investigador.

Ningún enlace se declara inaccesible en todo internet:registro_descargas.json refleja solicitudes reales, estados, redirecciones y fecha. Las copias locales preservadas permiten auditoría aun cuando cambie el servidor. Algunas fuentes secundarias se usaron sólo para descubrimiento y están separadas de evidencia de aceptación.

## Reejecución

`python scripts/validate_curves.py` desde la carpeta extraída comprueba CSV/JSON y genera nuevamente resultados y este informe. El entorno requiere Python3 y NumPy. El script de extracción adicional requiere PyMuPDF y las fuentes originales incluidas. Ver LEEME.md.

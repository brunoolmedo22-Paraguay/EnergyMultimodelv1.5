# SEEDS2 - Handoff de investigación eólica

Fecha:2026-11-09. No iniciar implementación. No se modificó el repositorio.

## Decisión entregada

3 listos: Vergnet GEV MP C275; Vestas V47-660 de UN generador; Vestas V52-850 OptiSpeed104.2dB(A).
5 priorizados pendientes: AriaLibellula20; NPS100C-21; NPS100C-24; EWT DW54-500; EWT DW54-900.
Los ocho priorizados no son ocho aprobados. No fusionar CANDIDATOS_CONDICIONALES.

## Archivos

- `candidatos_turbine_db.py`: esquema real de producción, con TURBINE_DB sólo de3listos; entradas condicionadas separadas.
- `curvas_potencia/`: CSV y manifiesto de condiciones/procedencia. Los RAW con negativos no son importables como generación no negativa.
- `SEEDS2_CANDIDATOS_EOLICOS.xlsx`:9hojas,68candidatos,15fichas, puntuaciones, fórmulas de validación y fuentes.
- `SEEDS2_RASTREABILIDAD_EOLICA.pdf`: evidencia por parámetro y dictámenes.
- `dataset_auditable.json`, `RESULTADOS_VALIDACION.json`: fuentes y resultados estructurados.
- `evidencia/`: documentos centrales, coordenadas de digitalización, copias de lectura de los4archivos deSEEDS2 y SHA de blob.

## Contrato contrastado

`config/wind_turbine_database.py`, `models/wind_model.py`, `wind_app.py`, `seeds2/microgrid/references.py` fueron leídos en main. Sus SHA están en evidencia/repo_snapshot/manifest.json. Volver a contrastar la versión vigente antes de una futura implementación.

Los seis equipos originales deben preservarse. No importar este módulo desde la app antes de autorización. Sólo se usan manufacturer_table y datasheet_graph_digitized; no se inventa un source_type para certificadosC dentro del contrato productivo.

## Condiciones pendientes concretas

- Aria20: v20..25 sin curva. No mantener16.4kW por defecto ni extender meseta. Restringir dominio o pedir tabla completa y aprobación de política.
- NPS21/24: elegir tratamiento de consumos auxiliares(-0.6kW) y preservar originales. La rama positiva es un subconjunto propuesto. NPS24 también tiene1.2kW a3m/s bajo cut-in3.5 y sobrepotencia95.3 frente95.
- EWT500/900: el último vértice calibrado está cerca24.86m/s; el corte es25. No redondear el vértice a25 ni inventar un dato de parada. Validar política de dominio, incluida velocidad equivalente por rho.
- SW1250: densidad no publicada; operación hasta35 y curva hasta16. No usar1.225 como si fuese fabricante.
- CurvasC(SD6/TN535/CF): preservar versión/ensayo, incertidumbre y potencia pico; no recortar a nominal para aprobar.

## Invariantes de la misión futura, una vez autorizada

1. Identidad exacta y variante, unidadeskW/m/s; no duplicar las6máquinas existentes.
2. Comparar puntos CSV con propuestaPython, velocidades crecientes y finitas, potencias finitas/no negativas de la rama aprobada.
3. Error nominal relativo,1% tablas/objetivo3% gráficos; no usar margen absoluto10kW para pequeños equipos.
4. No suavizar ni forzar monotonía; no prolongar fuera del dominio. Probar extremos, cut-in y v>=cut-out.
5. Rho conocida; perfil de viento a buje. No corregir altura automáticamente sin método acordado. Probar también límites sobre velocidad equivalente.
6. No aplicar eficiencia interna extra. Pérdida externa3% únicamente como opción separada ya existente.
7. Conservar V nominal publicada/inferida, fuentes, huellas y calidad; no convertir ausencias en valores típicos.
8. V47: un generador, tabla rho1.225 dePDF12(p. impresa6), no variante660/200. V52:104.2dB(A), no modo de bajo ruido.
9. Re-cut-in20 se registra enVestas; modelo actual no reproduce histéresis. La aprobación no valida control transitorio.
10. `hub_height_m=None` hasta elegir una torre; mantener opciones publicadas. No seleccionar primera altura como hecho del fabricante.

No crear ramas,PR ni cambios como parte de este handoff. Es un resumen para decidir y preparar una misión posterior.

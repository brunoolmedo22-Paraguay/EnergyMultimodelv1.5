# SEEDS2 — Paquete de insumos para Codex: 7 aerogeneradores

Este ZIP es un SUBCONJUNTO intacto del paquete de investigación Work fechado 2026-11-09. El material de Work NO implementó ni aprobó los cuatro equipos de pequeña eólica. Son objetivos adicionales autorizados por el usuario, sujetos a validación del nuevo contrato.

## Tres originalmente aceptados por Work
- Vergnet GEV MP C 275 kW — curvas_potencia/vergnet275.csv
- Vestas V47-660 kW, UN generador — curvas_potencia/vestas47.csv
- Vestas V52-850 kW OptiSpeed 104.2 dB(A) — curvas_potencia/vestas52.csv

## Cuatro adicionales, con datos de ensayo/referencia (NO aprobados automáticamente)
- Bergey Excel 10 — evidencia/nrel_data/BergeyExcel10_8.9kW_7.csv
- Bergey Excel 15 — evidencia/nrel_data/BergeyExcel15_15.6kW_9.6.csv
- Kestrel e400nb — evidencia/nrel_data/Kestrele400nb_2.5kW_4.csv
- SWIFT — evidencia/nrel_data/SWIFT_1kW_2.1.csv

Los cuatro contienen posibles potencias netas negativas (consumos auxiliares); no se deben borrar silenciosamente. Sus potencias máximas de curva pueden superar los valores de referencia, y el dominio de medida NO garantiza un cut-out operativo. Necesitan fuente/versión/condiciones verificadas y política EXPLÍCITA para vientos fuera del dominio.

Los archivos NLR/NatLabRockies NO deben etiquetarse como 'manufacturer_table' si no procede; consultar evidencia/nrel_data/manifest.json y los vínculos a los informes certificados. Se adjuntan cuatro PDF de fuentes principales disponibles en Work; otras fuentes pueden requerir descarga mediante URLs documentadas.

No cambiar EMS V2, no hacer merge. El objetivo es PR en rama independiente, con código/tests/dossier de trazabilidad y balance de energía verificables.

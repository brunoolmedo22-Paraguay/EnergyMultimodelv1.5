"""SEEDS2: propuesta de investigación, 2026-11-09. NO integrada ni importada por la app.
TURBINE_DB contiene sólo los equipos que superaron los requisitos excluyentes.
CANDIDATOS_CONDICIONALES NO están autorizados para incorporación.
None = no informado. No se infieren alturas de buje ni parámetros típicos.
Las tablas Vestas son calculadas por OEM, no mediciones de esta misión.
"""

TURBINE_DB = {'Vergnet GEV MP C 275 kW': {'spec': {'manufacturer': 'Vergnet',
                                      'model': 'GEV MP C 275 kW',
                                      'rated_power_kw': 275,
                                      'rotor_diameter_m': 32,
                                      'swept_area_m2': 804.0,
                                      'hub_height_m': None,
                                      'hub_height_options_m': [55, 60],
                                      'wind_class_iec': 'II a IV según configuración',
                                      'cut_in_mps': 3.5,
                                      'cut_in_range_mps': None,
                                      'rated_wind_speed_mps': 12.0,
                                      'rated_wind_speed_range_mps': None,
                                      'cut_out_mps': 25,
                                      'recut_in_mps': None,
                                      'reference_air_density_kg_m3': 1.225,
                                      'power_regulation': 'Pitch hidráulico',
                                      'generator': 'Asíncrono jaula de ardilla, dos velocidades, ABB',
                                      'frequency_hz': [50, 60],
                                      'design_lifetime_years': None,
                                      'notes': 'LISTO PARA INCORPORACIÓN. Tabla oficial eléctrica a 1.225 '
                                               'kg/m³, dominio hasta 25 m/s y meseta 12..25 explícita. V '
                                               'nominal se deriva a 12 m/s; no se atribuye al fabricante '
                                               'como especificación publicada. No se asigna una clase '
                                               'individual entre II y IV: debe elegirse la configuración de '
                                               'sitio. Tabla: 275 kW a 12 m/s y hasta 25 m/s. El punto '
                                               '25,275 representa la rama operativa, antes del disparo; '
                                               'SEEDS2 pone cero para v>=25. Frontera: tabla de potencia '
                                               'eléctrica del aerogenerador, medición exacta no explicitada. '
                                               'No deducir de la mención de transformador en gabinete que '
                                               'sus pérdidas están incluidas.'},
                             'curve': {'points': [(2.5, 0.0),
                                                  (3.0, 0.0),
                                                  (3.5, 0.0),
                                                  (4.0, 3.0),
                                                  (4.5, 10.0),
                                                  (5.0, 18.0),
                                                  (5.5, 27.0),
                                                  (6.0, 36.0),
                                                  (6.5, 47.0),
                                                  (7.0, 58.0),
                                                  (7.5, 78.0),
                                                  (8.0, 98.0),
                                                  (8.5, 119.0),
                                                  (9.0, 141.0),
                                                  (9.5, 164.0),
                                                  (10.0, 189.0),
                                                  (10.5, 215.0),
                                                  (11.0, 243.0),
                                                  (11.5, 262.0),
                                                  (12.0, 275.0),
                                                  (25.0, 275.0)],
                                       'source_type': 'manufacturer_table',
                                       'reference_density_kg_m3': 1.225,
                                       'min_wind_mps': 2.5,
                                       'max_wind_mps': 25.0,
                                       'density_correction': 'equivalent_wind_speed',
                                       'notes': 'Sólo dominio publicado. No extrapolar. Tabla oficial '
                                                'eléctrica a 1.225 kg/m³, dominio hasta 25 m/s y meseta '
                                                '12..25 explícita. V nominal se deriva a 12 m/s; no se '
                                                'atribuye al fabricante como especificación publicada.'},
                             'quality': {'cut_in': 'manufacturer_spec',
                                         'rated_wind_speed': 'derived_from_curve_first_rated_point',
                                         'cut_out': 'manufacturer_spec',
                                         'power_curve': 'exact_manufacturer_table'},
                             'source': {'document': 'DC-11-00-01-EN_GEV_MP-C_275_kW.pdf',
                                        'pages': [7],
                                        'reference': 'DC-11-00-01-EN; pie 04.14; '
                                                     'https://www.vergnet.com/wp-content/uploads/2023/06/DC-11-00-01-EN_GEV_MP-C_275_kW.pdf; '
                                                     'SHA256=05e8d865be60bbb96e9968c96edc6ca221fc5879c25c3c4eab4439d89ea79efa'},
                             'power_boundary': {'quantity': 'manufacturer_electrical_power_curve',
                                                'measurement_point': None,
                                                'measurement_point_label': 'Punto eléctrico exacto no '
                                                                           'informado',
                                                'internal_turbine_losses_reapplied': False,
                                                'downstream_grid_losses_included': False,
                                                'confidence': 'measurement_point_not_provided'}},
 'Vestas V47-660 kW': {'spec': {'manufacturer': 'Vestas',
                                'model': 'V47-660 kW',
                                'rated_power_kw': 660,
                                'rotor_diameter_m': 47,
                                'swept_area_m2': 1735.0,
                                'hub_height_m': None,
                                'hub_height_options_m': [40, 45, 50, 55],
                                'wind_class_iec': None,
                                'cut_in_mps': 4,
                                'cut_in_range_mps': None,
                                'rated_wind_speed_mps': 15,
                                'rated_wind_speed_range_mps': None,
                                'cut_out_mps': 25,
                                'recut_in_mps': 20,
                                'reference_air_density_kg_m3': 1.225,
                                'power_regulation': 'OptiTip pitch + OptiSlip deslizamiento variable',
                                'generator': 'Asíncrono OptiSlip, un generador, 690 V',
                                'frequency_hz': 50,
                                'design_lifetime_years': None,
                                'notes': 'LISTO PARA INCORPORACIÓN. Tabla oficial de la versión de un '
                                         'generador, rho=1.225; rango 19..25 publicado explícitamente. No '
                                         'mezclar con V47-660/200. Curva tabulada calculada por el '
                                         'fabricante a partir de perfiles NACA63.600/FFA-W3 y TI=10%, viento '
                                         'medio 10 min a buje y normal al rotor. No es un ajuste teórico '
                                         'creado para esta misión. No confundir tabla calculada p.PDF12 con '
                                         'medición TWE de apéndice ni con variante de dos generadores '
                                         'p.PDF14. V nominal publicada 15 m/s (folleto p.PDF4): P(15)=657 kW '
                                         '(99.55%). Primera velocidad >=99% a 15; primer valor exactamente '
                                         '660 a 17. Rearranque 20 m/s en p.PDF10 (impresa4). SEEDS2 registra '
                                         'el dato pero no simula histéresis; idóneo para balance energético '
                                         'estático, no para validar secuencias de parada/rearranque.'},
                       'curve': {'points': [(4.0, 2.9),
                                            (5.0, 43.8),
                                            (6.0, 96.7),
                                            (7.0, 166.0),
                                            (8.0, 252.0),
                                            (9.0, 350.0),
                                            (10.0, 450.0),
                                            (11.0, 538.0),
                                            (12.0, 600.0),
                                            (13.0, 635.0),
                                            (14.0, 651.0),
                                            (15.0, 657.0),
                                            (16.0, 659.0),
                                            (17.0, 660.0),
                                            (18.0, 660.0),
                                            (25.0, 660.0)],
                                 'source_type': 'manufacturer_table',
                                 'reference_density_kg_m3': 1.225,
                                 'min_wind_mps': 4.0,
                                 'max_wind_mps': 25.0,
                                 'density_correction': 'equivalent_wind_speed',
                                 'notes': 'Sólo dominio publicado. No extrapolar. Tabla oficial de la '
                                          'versión de un generador, rho=1.225; rango 19..25 publicado '
                                          'explícitamente. No mezclar con V47-660/200.'},
                       'quality': {'cut_in': 'manufacturer_spec',
                                   'rated_wind_speed': 'manufacturer_spec',
                                   'cut_out': 'manufacturer_spec',
                                   'power_curve': 'exact_manufacturer_table'},
                       'source': {'document': 'Vestas_V47.pdf',
                                  'pages': [12],
                                  'reference': '943111.R4, 02-05-00; pág. impresa 6 = pág. PDF 12; '
                                               'https://sti2d.ecolelamache.org/ressources/EE/premiere/TP/serie%202/Vestas_V47.pdf; '
                                               'SHA256=0aaf05e8c558f936f671759744ca56ae6ca2f9c6e8f9186783ca18ab76f1cad1'},
                       'power_boundary': {'quantity': 'manufacturer_electrical_power_curve',
                                          'measurement_point': None,
                                          'measurement_point_label': 'Punto eléctrico exacto no informado',
                                          'internal_turbine_losses_reapplied': False,
                                          'downstream_grid_losses_included': False,
                                          'confidence': 'measurement_point_not_provided'}},
 'Vestas V52-850 kW OptiSpeed': {'spec': {'manufacturer': 'Vestas',
                                          'model': 'V52-850 kW OptiSpeed',
                                          'rated_power_kw': 850,
                                          'rotor_diameter_m': 52,
                                          'swept_area_m2': 2124.0,
                                          'hub_height_m': None,
                                          'hub_height_options_m': [40, 44, 49, 55, 60, 65],
                                          'wind_class_iec': 'IA (torres seleccionadas; otras combinaciones '
                                                            'IIA/DIBt en p.4)',
                                          'cut_in_mps': 4,
                                          'cut_in_range_mps': None,
                                          'rated_wind_speed_mps': 17.0,
                                          'rated_wind_speed_range_mps': None,
                                          'cut_out_mps': 25,
                                          'recut_in_mps': 20,
                                          'reference_air_density_kg_m3': 1.225,
                                          'power_regulation': 'Pitch OptiTip y velocidad variable OptiSpeed',
                                          'generator': 'Asíncrono de rotor bobinado, OptiSpeed (DFIG), 690 V',
                                          'frequency_hz': [50, 60],
                                          'design_lifetime_years': None,
                                          'notes': 'LISTO PARA INCORPORACIÓN. Tabla oficial a 1.225 kg/m³ y '
                                                   'modo acústico 104.2 dB(A). Rango 18..25 expresamente '
                                                   'constante. V nominal inferida, sin mezclar otras curvas '
                                                   'acústicas. Curvas/tablas calculadas oficialmente con '
                                                   'perfiles NACA63/FFA-W3. No son mediciones nuevas ni una '
                                                   'curva genérica cúbica. Curva nominal seleccionada: ruido '
                                                   '104.2 dB(A), TI=10%, viento medio 10 minutos a buje '
                                                   'perpendicular al plano del rotor. No usar tablas '
                                                   '103/102/101/100 dB(A). Frontera publicada p.PDF7: '
                                                   'excluye pérdidas del transformador y cables de alta '
                                                   'tensión. No reaplicar eficiencias de '
                                                   'rotor/caja/generador. V nominal no fijada en la tabla '
                                                   'seleccionada: primer >=99% a 15 m/s; primer valor '
                                                   'exactamente 850 a 17 m/s. Se propone 17 derivada '
                                                   '(criterio alcance exacto). Rearranque 20 m/s p.PDF6. El '
                                                   'modelo actual no representa histéresis ni ventanas de '
                                                   'control de 10 minutos.'},
                                 'curve': {'points': [(4.0, 25.5),
                                                      (5.0, 67.4),
                                                      (6.0, 125.0),
                                                      (7.0, 203.0),
                                                      (8.0, 304.0),
                                                      (9.0, 425.0),
                                                      (10.0, 554.0),
                                                      (11.0, 671.0),
                                                      (12.0, 759.0),
                                                      (13.0, 811.0),
                                                      (14.0, 836.0),
                                                      (15.0, 846.0),
                                                      (16.0, 849.0),
                                                      (17.0, 850.0),
                                                      (18.0, 850.0),
                                                      (25.0, 850.0)],
                                           'source_type': 'manufacturer_table',
                                           'reference_density_kg_m3': 1.225,
                                           'min_wind_mps': 4.0,
                                           'max_wind_mps': 25.0,
                                           'density_correction': 'equivalent_wind_speed',
                                           'notes': 'Sólo dominio publicado. No extrapolar. Tabla oficial a '
                                                    '1.225 kg/m³ y modo acústico 104.2 dB(A). Rango 18..25 '
                                                    'expresamente constante. V nominal inferida, sin mezclar '
                                                    'otras curvas acústicas.'},
                                 'quality': {'cut_in': 'manufacturer_spec',
                                             'rated_wind_speed': 'derived_from_curve_first_rated_point',
                                             'cut_out': 'manufacturer_spec',
                                             'power_curve': 'exact_manufacturer_table'},
                                 'source': {'document': 'V52-850kWh%20Gen%20Spec-1-1.pdf',
                                            'pages': [8],
                                            'reference': '946506 V10, 2008-10-08; '
                                                         'https://mkwind.pl/uploads/filemanager/PDF/V52-850kWh%20Gen%20Spec-1-1.pdf; '
                                                         'SHA256=39e52a04fd0733c0deef916e18f91d1c5edca1ea10a37e681a14a59b19f34263'},
                                 'power_boundary': {'quantity': 'manufacturer_electrical_power_curve',
                                                    'measurement_point': 'ground_controller_low_voltage_side_of_transformer',
                                                    'measurement_point_label': 'Controlador a nivel de '
                                                                               'suelo, lado de baja tensión '
                                                                               'del transformador (p.PDF7)',
                                                    'internal_turbine_losses_reapplied': False,
                                                    'downstream_grid_losses_included': False,
                                                    'confidence': 'manufacturer_explicit'}}}

CANDIDATOS_CONDICIONALES = {'Aria Libellula 20kW': {'spec': {'manufacturer': 'Aria',
                                  'model': 'Libellula 20kW',
                                  'rated_power_kw': 20,
                                  'rotor_diameter_m': 17.4,
                                  'swept_area_m2': 237.7871479502114,
                                  'hub_height_m': None,
                                  'hub_height_options_m': [20.5, 26.5],
                                  'wind_class_iec': 'IIIA',
                                  'cut_in_mps': 2.5,
                                  'cut_in_range_mps': None,
                                  'rated_wind_speed_mps': 10,
                                  'rated_wind_speed_range_mps': None,
                                  'cut_out_mps': 25,
                                  'recut_in_mps': None,
                                  'reference_air_density_kg_m3': 1.225,
                                  'power_regulation': 'Stall pasivo',
                                  'generator': 'Asíncrono, 4 polos, 400 V',
                                  'frequency_hz': 50,
                                  'design_lifetime_years': None,
                                  'notes': 'PENDIENTE. La tabla termina en 20 m/s y el cut-out es 25 m/s. '
                                           'Falta la rama decreciente 20..25; mantener 16.4 kW sería una '
                                           'extrapolación no autorizada. No elegir automáticamente altura: '
                                           'el perfil debe representar viento a buje. V nominal publicada 10 '
                                           'm/s: tabla 19.3 kW. Primer punto >=99% de 20 kW a 11 m/s; se '
                                           'conservan ambas magnitudes. Condiciones: 15 °C, 1013 mbar, 1.225 '
                                           'kg/m³, flujo horizontal sin perturbaciones, equipo en perfecto '
                                           'estado. Conexión directa a red, sin inversor.'},
                         'curve': {'points': [(0.0, 0.0),
                                              (1.0, 0.0),
                                              (2.0, 0.0),
                                              (3.0, 1.0),
                                              (4.0, 3.7),
                                              (5.0, 7.2),
                                              (6.0, 10.7),
                                              (7.0, 14.1),
                                              (8.0, 16.5),
                                              (9.0, 18.3),
                                              (10.0, 19.3),
                                              (11.0, 19.9),
                                              (12.0, 19.9),
                                              (13.0, 19.8),
                                              (14.0, 19.4),
                                              (15.0, 18.9),
                                              (16.0, 18.3),
                                              (17.0, 17.8),
                                              (18.0, 17.2),
                                              (19.0, 16.9),
                                              (20.0, 16.4)],
                                   'source_type': 'manufacturer_table',
                                   'reference_density_kg_m3': 1.225,
                                   'min_wind_mps': 0.0,
                                   'max_wind_mps': 20.0,
                                   'density_correction': 'equivalent_wind_speed',
                                   'notes': 'Sólo dominio publicado. No extrapolar. La tabla termina en 20 '
                                            'm/s y el cut-out es 25 m/s. Falta la rama decreciente 20..25; '
                                            'mantener 16.4 kW sería una extrapolación no autorizada.'},
                         'quality': {'cut_in': 'manufacturer_spec',
                                     'rated_wind_speed': 'manufacturer_spec',
                                     'cut_out': 'manufacturer_spec',
                                     'power_curve': 'exact_manufacturer_table'},
                         'source': {'document': 'Power-Curve-AEP-Libellula-20kW.pdf',
                                    'pages': [1],
                                    'reference': 'Depliant 20kW 2016-e (título); curva sin revisión visible; '
                                                 'https://www.aria-srl.it/aria-staging/wp-content/uploads/2016/09/Power-Curve-AEP-Libellula-20kW.pdf; '
                                                 'SHA256=d70a5735a71efa1d58bf572528f692582bfb50f1072130d5037e0a494bcc23be'},
                         'power_boundary': {'quantity': 'manufacturer_electrical_power_curve',
                                            'measurement_point': None,
                                            'measurement_point_label': 'Punto eléctrico exacto no informado',
                                            'internal_turbine_losses_reapplied': False,
                                            'downstream_grid_losses_included': False,
                                            'confidence': 'measurement_point_not_provided'}},
 'Northern Power Systems 100C-21': {'spec': {'manufacturer': 'Northern Power Systems',
                                             'model': '100C-21',
                                             'rated_power_kw': 100,
                                             'rotor_diameter_m': 20.7,
                                             'swept_area_m2': 336.53525903417255,
                                             'hub_height_m': None,
                                             'hub_height_options_m': [22, 29, 37],
                                             'wind_class_iec': 'IEC WTGS II/A',
                                             'cut_in_mps': 3,
                                             'cut_in_range_mps': None,
                                             'rated_wind_speed_mps': 15,
                                             'rated_wind_speed_range_mps': None,
                                             'cut_out_mps': 25,
                                             'recut_in_mps': None,
                                             'reference_air_density_kg_m3': 1.225,
                                             'power_regulation': 'Velocidad variable y stall',
                                             'generator': 'Imanes permanentes, direct drive',
                                             'frequency_hz': 50,
                                             'design_lifetime_years': 20,
                                             'notes': 'PENDIENTE. La tabla neta original incluye -0.6 kW a 1 '
                                                      'y 2 m/s. La propuesta conserva sólo la rama no '
                                                      'negativa: requiere aceptar explícitamente que los '
                                                      'consumos auxiliares quedan fuera del perfil de '
                                                      'generación. Rama de generación propuesta: v=3..25 '
                                                      'm/s. El CSV *_raw preserva todos los valores, '
                                                      'incluidos negativos. La leyenda del gráfico dice NPS '
                                                      '100C-24 dentro del folleto 100C-21: contradicción '
                                                      'editorial. Identidad fijada por portada, título de '
                                                      'curva, tabla de especificaciones y rotor 20.7 m; '
                                                      'tabla contrastada con NLR independiente. Condiciones '
                                                      'estándar 1.225 kg/m³, equivalentes a 15 °C al nivel '
                                                      'del mar. Punto de medición exacto no indicado.'},
                                    'curve': {'points': [(3.0, 0.5),
                                                         (4.0, 4.1),
                                                         (5.0, 10.5),
                                                         (6.0, 19.0),
                                                         (7.0, 29.4),
                                                         (8.0, 41.0),
                                                         (9.0, 54.3),
                                                         (10.0, 66.8),
                                                         (11.0, 77.7),
                                                         (12.0, 86.4),
                                                         (13.0, 92.8),
                                                         (14.0, 97.8),
                                                         (15.0, 100.0),
                                                         (16.0, 99.9),
                                                         (17.0, 99.2),
                                                         (18.0, 98.4),
                                                         (19.0, 97.5),
                                                         (20.0, 96.8),
                                                         (21.0, 96.4),
                                                         (22.0, 96.3),
                                                         (23.0, 96.8),
                                                         (24.0, 98.0),
                                                         (25.0, 99.2)],
                                              'source_type': 'manufacturer_table',
                                              'reference_density_kg_m3': 1.225,
                                              'min_wind_mps': 3.0,
                                              'max_wind_mps': 25.0,
                                              'density_correction': 'equivalent_wind_speed',
                                              'notes': 'Sólo dominio publicado. No extrapolar. Rama de '
                                                       'generación; originales negativos preservados en '
                                                       '*_raw.csv. La tabla neta original incluye -0.6 kW a '
                                                       '1 y 2 m/s. La propuesta conserva sólo la rama no '
                                                       'negativa: requiere aceptar explícitamente que los '
                                                       'consumos auxiliares quedan fuera del perfil de '
                                                       'generación.'},
                                    'quality': {'cut_in': 'manufacturer_spec',
                                                'rated_wind_speed': 'manufacturer_spec',
                                                'cut_out': 'manufacturer_spec',
                                                'power_curve': 'exact_manufacturer_table'},
                                    'source': {'document': 'brochure-NPS-100C-21_ed2020_light_ENG.pdf',
                                               'pages': [2],
                                               'reference': 'ed2020 en nombre original; revisión interna no '
                                                            'visible; '
                                                            'https://northernpower.com/wp/wp-content/uploads/2025/11/brochure-NPS-100C-21_ed2020_light_ENG.pdf; '
                                                            'SHA256=b1977a516fda839d4d68410d92ff8587ce21908c6203d1b1185a505aa14f2288'},
                                    'power_boundary': {'quantity': 'manufacturer_electrical_power_curve',
                                                       'measurement_point': None,
                                                       'measurement_point_label': 'Punto eléctrico exacto no '
                                                                                  'informado',
                                                       'internal_turbine_losses_reapplied': False,
                                                       'downstream_grid_losses_included': False,
                                                       'confidence': 'measurement_point_not_provided'}},
 'Northern Power Systems 100C-24': {'spec': {'manufacturer': 'Northern Power Systems',
                                             'model': '100C-24',
                                             'rated_power_kw': 95,
                                             'rotor_diameter_m': 24.4,
                                             'swept_area_m2': 467.59465056030473,
                                             'hub_height_m': None,
                                             'hub_height_options_m': [30, 37],
                                             'wind_class_iec': 'IEC WTGS III/A',
                                             'cut_in_mps': 3.5,
                                             'cut_in_range_mps': None,
                                             'rated_wind_speed_mps': 12,
                                             'rated_wind_speed_range_mps': None,
                                             'cut_out_mps': 25,
                                             'recut_in_mps': None,
                                             'reference_air_density_kg_m3': 1.225,
                                             'power_regulation': 'Velocidad variable y stall',
                                             'generator': 'Imanes permanentes, direct drive',
                                             'frequency_hz': 50,
                                             'design_lifetime_years': 20,
                                             'notes': 'PENDIENTE. Requiere política explícita para '
                                                      'auxiliares negativos y punto de 3 m/s positivo bajo '
                                                      'el cut-in de 3.5 m/s. El clip actual recortaría 95.3 '
                                                      'a 95 kW. Potencia nominal eléctrica real: 95 kW. No '
                                                      'usar 100 kW por el nombre comercial. Tabla completa '
                                                      'original con -0.6 kW a 1 y 2 m/s guardada como '
                                                      'nps24_raw. Rama de generación propuesta sin recortar '
                                                      'máximos. La tabla publica 1.2 kW a 3 m/s, la portada '
                                                      'menciona generación desde 3 m/s y especificación '
                                                      'cut-in 3.5 m/s. Resolución de 1 m/s y control de '
                                                      'arranque pueden explicar parte de la diferencia; no '
                                                      'se demuestra equivalencia exacta. P(12)=94.7 kW '
                                                      '(~99.68%); primer punto >=99% a 12 m/s, coherente con '
                                                      'nominal declarada.'},
                                    'curve': {'points': [(3.0, 1.2),
                                                         (4.0, 7.2),
                                                         (5.0, 14.5),
                                                         (6.0, 24.7),
                                                         (7.0, 37.9),
                                                         (8.0, 58.7),
                                                         (9.0, 74.8),
                                                         (10.0, 85.1),
                                                         (11.0, 90.2),
                                                         (12.0, 94.7),
                                                         (13.0, 95.3),
                                                         (14.0, 95.1),
                                                         (15.0, 94.2),
                                                         (16.0, 92.9),
                                                         (17.0, 91.2),
                                                         (18.0, 88.9),
                                                         (19.0, 87.1),
                                                         (20.0, 84.1),
                                                         (21.0, 81.3),
                                                         (22.0, 78.6),
                                                         (23.0, 76.1),
                                                         (24.0, 74.3),
                                                         (25.0, 71.7)],
                                              'source_type': 'manufacturer_table',
                                              'reference_density_kg_m3': 1.225,
                                              'min_wind_mps': 3.0,
                                              'max_wind_mps': 25.0,
                                              'density_correction': 'equivalent_wind_speed',
                                              'notes': 'Sólo dominio publicado. No extrapolar. Rama de '
                                                       'generación; originales negativos preservados en '
                                                       '*_raw.csv. Requiere política explícita para '
                                                       'auxiliares negativos y punto de 3 m/s positivo bajo '
                                                       'el cut-in de 3.5 m/s. El clip actual recortaría 95.3 '
                                                       'a 95 kW.'},
                                    'quality': {'cut_in': 'manufacturer_spec',
                                                'rated_wind_speed': 'manufacturer_spec',
                                                'cut_out': 'manufacturer_spec',
                                                'power_curve': 'exact_manufacturer_table'},
                                    'source': {'document': 'brochure-NPS-100C-24_ed2020_light_ENG.pdf',
                                               'pages': [2],
                                               'reference': 'ed2020 en nombre original; revisión interna no '
                                                            'visible; '
                                                            'https://northernpower.com/wp/wp-content/uploads/2024/04/brochure-NPS-100C-24_ed2020_light_ENG.pdf; '
                                                            'SHA256=ef3d0e58462d4ea80fe5a8c7060cb1417f9e674b5bad4da15d1323a2d0f5ac92'},
                                    'power_boundary': {'quantity': 'manufacturer_electrical_power_curve',
                                                       'measurement_point': None,
                                                       'measurement_point_label': 'Punto eléctrico exacto no '
                                                                                  'informado',
                                                       'internal_turbine_losses_reapplied': False,
                                                       'downstream_grid_losses_included': False,
                                                       'confidence': 'measurement_point_not_provided'}},
 'EWT DW54-500': {'spec': {'manufacturer': 'EWT',
                           'model': 'DW54-500',
                           'rated_power_kw': 500,
                           'rotor_diameter_m': 54,
                           'swept_area_m2': 2290.221044466959,
                           'hub_height_m': None,
                           'hub_height_options_m': [40, 50, 75],
                           'wind_class_iec': 'IIIA',
                           'cut_in_mps': 3,
                           'cut_in_range_mps': None,
                           'rated_wind_speed_mps': 9.950661278720233,
                           'rated_wind_speed_range_mps': None,
                           'cut_out_mps': 25,
                           'recut_in_mps': None,
                           'reference_air_density_kg_m3': 1.225,
                           'power_regulation': None,
                           'generator': 'Direct drive; tipo eléctrico específico no explicitado en este '
                                        'folleto',
                           'frequency_hz': None,
                           'design_lifetime_years': None,
                           'notes': 'PENDIENTE. Digitalización validada. El extremo numérico queda ~0.14 m/s '
                                    'antes de 25 por el propio dibujo. Falta aceptar dominio restringido o '
                                    'documentar ese intervalo; no se prolonga la curva. Densidad 1.225 '
                                    'kg/m³, 15 °C, exponente de cizalladura 1/7, terreno no complejo, flujo '
                                    'sin inclinación y palas limpias. Fuente: curva azul de potencia kW; '
                                    'curva roja Cp no se usa como potencia. Ejes lineales. 23 vértices '
                                    'recuperados sin redondear velocidades a enteros. Potencia eléctrica: '
                                    'sin pérdidas de transformador ni otras externas según folleto. Punto '
                                    'exacto no explicitado. SEEDS2 recibe viento a altura de buje. No '
                                    'reproduce perfil vertical 1/7 sobre el rotor ni ajusta automáticamente '
                                    'altura de medición. La antigua página /products/dw54/ aparece en '
                                    'buscadores, pero devolvió404 en verificación directa. Se usa /turbines/ '
                                    'como página oficial activa y se conserva el PDF técnico200 como '
                                    'evidencia de parámetros. V nominal no publicada. Primer vértice >=99% '
                                    'nominal: 9.95066 m/s.'},
                  'curve': {'points': [(2.9912600872172965, 11.998570719762807),
                                       (3.9854726911755414, 39.001063900380416),
                                       (4.979684640726232, 77.9975883443237),
                                       (5.973811517294807, 138.0010494482072),
                                       (6.968024121253053, 222.0016519915404),
                                       (7.962236070803743, 336.99979359364517),
                                       (8.956448674761988, 477.0028359558151),
                                       (9.950661278720233, 499.99819348154216),
                                       (10.944787500881255, 499.99819348154216),
                                       (11.939083869006504, 499.99819348154216),
                                       (12.933212708797743, 499.99819348154216),
                                       (13.927338930958765, 499.99819348154216),
                                       (14.921637916714234, 499.99819348154216),
                                       (15.915761521245036, 499.99819348154216),
                                       (16.910060507000505, 499.99819348154216),
                                       (17.904186729161527, 499.99819348154216),
                                       (18.898315568952768, 499.99819348154216),
                                       (19.892611937078016, 499.99819348154216),
                                       (20.886738159239037, 499.99819348154216),
                                       (21.881037144994504, 499.99819348154216),
                                       (22.875163367155526, 499.99819348154216),
                                       (23.869289589316548, 499.99819348154216),
                                       (24.86341581147757, 499.99819348154216)],
                            'source_type': 'datasheet_graph_digitized',
                            'reference_density_kg_m3': 1.225,
                            'min_wind_mps': 2.9912600872172965,
                            'max_wind_mps': 24.86341581147757,
                            'density_correction': 'equivalent_wind_speed',
                            'notes': 'Sólo dominio publicado. No extrapolar. Digitalización validada. El '
                                     'extremo numérico queda ~0.14 m/s antes de 25 por el propio dibujo. '
                                     'Falta aceptar dominio restringido o documentar ese intervalo; no se '
                                     'prolonga la curva.'},
                  'quality': {'cut_in': 'manufacturer_spec',
                              'rated_wind_speed': 'derived_from_curve_first_rated_point',
                              'cut_out': 'manufacturer_spec',
                              'power_curve': 'digitized_from_manufacturer_graph'},
                  'source': {'document': 'EWT_DW54.pdf',
                             'pages': [2],
                             'reference': 'EWT_DW54.pdf; sin revisión/año visibles (ruta 2023/11 no prueba '
                                          'fecha); '
                                          'https://ewtdirectwind.com/wp-content/uploads/2023/11/EWT_DW54.pdf; '
                                          'SHA256=479f75dbf95e982b4ce27c0ae3d5e90769fbfd88721ddaf2ba3f90f177acf1c1'},
                  'power_boundary': {'quantity': 'manufacturer_electrical_power_curve',
                                     'measurement_point': None,
                                     'measurement_point_label': 'Punto eléctrico exacto no informado',
                                     'internal_turbine_losses_reapplied': False,
                                     'downstream_grid_losses_included': False,
                                     'confidence': 'measurement_point_not_provided'}},
 'EWT DW54-900': {'spec': {'manufacturer': 'EWT',
                           'model': 'DW54-900',
                           'rated_power_kw': 900,
                           'rotor_diameter_m': 54,
                           'swept_area_m2': 2290.221044466959,
                           'hub_height_m': None,
                           'hub_height_options_m': [40, 50, 75],
                           'wind_class_iec': 'IIIA',
                           'cut_in_mps': 3,
                           'cut_in_range_mps': None,
                           'rated_wind_speed_mps': 13.92734453877764,
                           'rated_wind_speed_range_mps': None,
                           'cut_out_mps': 25,
                           'recut_in_mps': None,
                           'reference_air_density_kg_m3': 1.225,
                           'power_regulation': None,
                           'generator': 'Direct drive; tipo eléctrico específico no explicitado en este '
                                        'folleto',
                           'frequency_hz': None,
                           'design_lifetime_years': None,
                           'notes': 'PENDIENTE. Digitalización validada. El extremo numérico queda ~0.14 m/s '
                                    'antes de 25 por el propio dibujo. Falta aceptar dominio restringido o '
                                    'documentar ese intervalo; no se prolonga la curva. Densidad 1.225 '
                                    'kg/m³, 15 °C, exponente de cizalladura 1/7, terreno no complejo, flujo '
                                    'sin inclinación y palas limpias. Fuente: curva azul de potencia kW; '
                                    'curva roja Cp no se usa como potencia. Ejes lineales. 23 vértices '
                                    'recuperados sin redondear velocidades a enteros. Potencia eléctrica: '
                                    'sin pérdidas de transformador ni otras externas según folleto. Punto '
                                    'exacto no explicitado. SEEDS2 recibe viento a altura de buje. No '
                                    'reproduce perfil vertical 1/7 sobre el rotor ni ajusta automáticamente '
                                    'altura de medición. La antigua página /products/dw54/ aparece en '
                                    'buscadores, pero devolvió404 en verificación directa. Se usa /turbines/ '
                                    'como página oficial activa y se conserva el PDF técnico200 como '
                                    'evidencia de parámetros. V nominal no publicada. Primer vértice >=99% '
                                    'nominal: 13.92734 m/s.'},
                  'curve': {'points': [(2.991268634323003, 11.9989853854709),
                                       (3.985481090053007, 39.00151988393275),
                                       (4.979692891375553, 78.00100164484797),
                                       (5.97381961972867, 138.00148708864293),
                                       (6.968032075458673, 222.00198142605552),
                                       (7.96224387678122, 337.0001017208408),
                                       (8.956455678103767, 476.9970964159217),
                                       (9.950667479426313, 604.9999231070541),
                                       (10.944879935156317, 732.9997852557813),
                                       (11.939006009101975, 827.0000516939924),
                                       (12.93321846483198, 884.0013466431491),
                                       (13.92734453877764, 899.9994997332242),
                                       (14.921644685106902, 899.9994997332242),
                                       (15.915768141422733, 899.9994997332242),
                                       (16.91006697893708, 899.9994997332242),
                                       (17.90419305288274, 899.9994997332242),
                                       (18.898321744458226, 899.9994997332242),
                                       (19.892617964342747, 899.9994997332242),
                                       (20.886744038288406, 899.9994997332242),
                                       (21.881042875802756, 899.9994997332242),
                                       (22.87516894974841, 899.9994997332242),
                                       (23.86929502369407, 899.9994997332242),
                                       (24.86342109763973, 899.9994997332242)],
                            'source_type': 'datasheet_graph_digitized',
                            'reference_density_kg_m3': 1.225,
                            'min_wind_mps': 2.991268634323003,
                            'max_wind_mps': 24.86342109763973,
                            'density_correction': 'equivalent_wind_speed',
                            'notes': 'Sólo dominio publicado. No extrapolar. Digitalización validada. El '
                                     'extremo numérico queda ~0.14 m/s antes de 25 por el propio dibujo. '
                                     'Falta aceptar dominio restringido o documentar ese intervalo; no se '
                                     'prolonga la curva.'},
                  'quality': {'cut_in': 'manufacturer_spec',
                              'rated_wind_speed': 'derived_from_curve_first_rated_point',
                              'cut_out': 'manufacturer_spec',
                              'power_curve': 'digitized_from_manufacturer_graph'},
                  'source': {'document': 'EWT_DW54.pdf',
                             'pages': [1],
                             'reference': 'EWT_DW54.pdf; sin revisión/año visibles (ruta 2023/11 no prueba '
                                          'fecha); '
                                          'https://ewtdirectwind.com/wp-content/uploads/2023/11/EWT_DW54.pdf; '
                                          'SHA256=479f75dbf95e982b4ce27c0ae3d5e90769fbfd88721ddaf2ba3f90f177acf1c1'},
                  'power_boundary': {'quantity': 'manufacturer_electrical_power_curve',
                                     'measurement_point': None,
                                     'measurement_point_label': 'Punto eléctrico exacto no informado',
                                     'internal_turbine_losses_reapplied': False,
                                     'downstream_grid_losses_included': False,
                                     'confidence': 'measurement_point_not_provided'}}}
